# //////////////////////////////////////// Setup

import numpy as np
import tensorflow as tf
import pandas as pd
import seaborn as sb
import matplotlib.pyplot as pyplot
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
from sklearn.metrics import RocCurveDisplay

# //////////////////////////////////////// Load model
first_model = "1649745611"
second_model = "1650027935"
import_first_path = "./tmp/saved_models/{}".format(int(first_model))
import_second_path = "./tmp/saved_models/{}".format(int(second_model))
model = tf.keras.models.load_model(import_first_path)
model2 = tf.keras.models.load_model(import_second_path)

# //////////////////////////////////////// Load data
data_root = "./safetyBatches/My_Batch_1/"
batch_size = 32
img_height = 224
img_width = 224

test_ds = tf.keras.utils.image_dataset_from_directory(
  data_root,
  seed=123,
  image_size=(img_height, img_width),
  batch_size=batch_size,
  shuffle=False
)

# Get information on classes
class_names = np.array(test_ds.class_names)
print('Classes available: ', class_names)

# get the ground truth labels
test_labels = np.concatenate([y for x, y in test_ds], axis=0)

# set ground truth in the value of classes
for i in range(0, len(test_labels)):
    test_labels[i] = int(class_names[test_labels[i]])

# Remember that we had some preprocessing before our training this needs to be repeated here
# Preprocessing as the tensorflow hub models expect images as float inputs [0,1]
normalization_layer = tf.keras.layers.Rescaling(1./255)
test_ds = test_ds.map(lambda x, y: (normalization_layer(x), y))  # Where x—images, y—labels.


# //////////////////////////////////////// Inference.
predictions = model.predict(test_ds)
predictions = np.argmax(predictions, axis=1)

predictions2 = model2.predict(test_ds)
predictions2 = np.argmax(predictions2, axis=1)

# categorize prediction by velocity shield or not
def binarpred(prediction):
    binary_prediction = prediction.copy()
    for i in range(0, len(prediction)):
        if (prediction[i] > 8 and prediction[i] != 32):
            binary_prediction[i] = 43
        else:
            binary_prediction[i] = 44
    return binary_prediction

# categorize prediction by all velocity shields and the rest
def predcorrect(prediction):
    prediction_correct = prediction.copy()
    for i in range(0, len(prediction)):
        if (prediction[i] > 8 and prediction[i] != 32):
            prediction_correct[i] = 43
    return prediction_correct

# simply print of predictions and ground truth
"""print('Predictions1: ', predictions)
print('Corrected Predictions1: ', predcorrect(predictions))
print('Binary Predictions1: ', binarpred(predictions))
print('Predictions2: ', predictions2)
print('Corrected Predictions2: ', predcorrect(predictions2))
print('Binary Predictions2: ', binarpred(predictions2))
print('Ground truth: ', test_labels)"""

# //////////////////////////////////////// Let the validation begin
# Probably you will want to at least migrate these to another script or class when this grows...

# calculate accuracy
def accuracy(predictions, test_labels):
    metric = tf.keras.metrics.Accuracy()
    metric.update_state(predictions, test_labels)
    return metric.result().numpy()


# print of accuracies
"""print('Accuracy1: ', accuracy(predictions, test_labels))
print('Binary Accuracy1', accuracy(binarpred(predictions), binarpred(test_labels)))
print('Corrected Accuracy1: ', accuracy(predcorrect(predictions), test_labels))
print('Accuracy2: ', accuracy(predictions2, test_labels))
print('Binary Accuracy2', accuracy(binarpred(predictions2), binarpred(test_labels)))
print('Corrected Accuracy2: ', accuracy(predcorrect(predictions2), test_labels))"""


# get confusion matrix from predictions
def get_conf_matrix(prediction, test_lab=test_labels):
    if (test_lab.all() == test_labels.all()):
        return pd.crosstab(test_lab, predcorrect(prediction), rownames=['True Value'], colnames=['Prediction'])
    else:
        return pd.crosstab(test_lab, binarpred(prediction), rownames=['True Value'], colnames=['Prediction'])


# print of confusion matrices
"""print(get_conf_matrix(predictions, binarpred(test_labels)))
print(get_conf_matrix(predictions2, binarpred(test_labels)))
print(get_conf_matrix(predictions))
print(get_conf_matrix(predictions2))"""


# get the parameters of a binary confusion matrix
def get_stat_class(conf_matrix):
    stat = []
    tp = conf_matrix.iloc[0, 0]
    fp = conf_matrix.iloc[0, 1]
    fn = conf_matrix.iloc[1, 0]
    tn = conf_matrix.iloc[1, 1]
    acc = (tp + tn) / (tp + fp + fn + tn)
    prec = tp / (tp + fp)
    tpr = tp / (tp + fn)
    fpr = 1 - tn / (tn + fp)
    f1 = (2 * prec * tpr) / (prec + tpr)
    stat.append([tp, fp, fn, tn, acc, prec, tpr, fpr, f1])
    return stat


# get an array of parameters of multiple class confusion matrix
def get_stat_by_class(conf_matrix):
    stats = []
    num = conf_matrix.sum().sum()

    for i in range(conf_matrix.shape[0]):
        tp = conf_matrix.iloc[i, i]
        fp = conf_matrix.iloc[i, :].sum()-tp
        fn = conf_matrix.iloc[:, i].sum()-tp
        tn = num-tp-fp-fn
        acc = (tp+tn)/num
        prec = tp/(tp+fp)
        tpr = tp/(tp+fn)
        fpr = 1-tn/(tn+fp)
        f1 = (2*prec*tpr)/(prec+tpr)
        stats.append([conf_matrix.index[i], tp, fp, fn, tn, acc, prec, tpr, fpr, f1])
    return stats


# print stats of matrices
"""print(get_stat_class(get_conf_matrix(predictions, binarpred(test_labels))))
print(get_stat_class(get_conf_matrix(predictions2, binarpred(test_labels))))
print(get_stat_by_class(get_conf_matrix(predictions)))
print(get_stat_by_class(get_conf_matrix(predictions2)))"""

# //////////////////////////////////////// creating figures to report

# plot of binary confusion matrix
figure = pyplot.figure(figsize=(20, 8))
ax = pyplot.subplot(121)
sb.heatmap(get_conf_matrix(predictions, binarpred(test_labels)), annot=True, cmap='Blues')
ax0 = pyplot.subplot(122)
sb.heatmap(get_conf_matrix(predictions2, binarpred(test_labels)), annot=True, cmap='Blues')

# plot of multiple class confusion matrix
figure1 = pyplot.figure(figsize=(20, 8))
ax1 = pyplot.subplot(121)
sb.heatmap(get_conf_matrix(predictions), annot=True, cmap='Blues')
ax2 = pyplot.subplot(122)
sb.heatmap(get_conf_matrix(predictions2), annot=True, cmap='Blues')

# plot of stats of multiple class matrix
figure2 = pyplot.figure(figsize=(15, 8))
figure2.patch.set_visible(False)
ax3 = pyplot.subplot(2, 1, 1)
ax3.axis('off')
ax3.axis('tight')
df1 = pd.DataFrame(get_stat_by_class(get_conf_matrix(predictions)), columns=['Category', 'TP', 'FP', 'FN', 'TN', 'Accuracy', 'Precision', 'TPR', 'FPR', 'F1-Score'])
ax3.table(cellText=df1.values, colLabels=df1.columns)
ax4 = pyplot.subplot(2, 1, 2)
ax4.axis('off')
ax4.axis('tight')
df2 = pd.DataFrame(get_stat_by_class(get_conf_matrix(predictions2)), columns=['Category', 'TP', 'FP', 'FN', 'TN', 'Accuracy', 'Precision', 'TPR', 'FPR', 'F1-Score'])
ax4.table(cellText=df2.values, colLabels=df2.columns)
figure2.tight_layout()

# plot of stat of binary confusion matrix
figure3 = pyplot.figure(figsize=(15, 8))
figure3.patch.set_visible(False)
ax5 = pyplot.subplot(2, 1, 1)
ax5.axis('off')
ax5.axis('tight')
df3 = pd.DataFrame(get_stat_class(get_conf_matrix(predictions, binarpred(test_labels))), columns=['TP', 'FP', 'FN', 'TN', 'Accuracy', 'Precision', 'TPR', 'FPR', 'F1-Score'])
ax5.table(cellText=df3.values, colLabels=df3.columns)
ax6 = pyplot.subplot(2, 1, 2)
ax6.axis('off')
ax6.axis('tight')
df4 = pd.DataFrame(get_stat_class(get_conf_matrix(predictions2, binarpred(test_labels))), columns=['TP', 'FP', 'FN', 'TN', 'Accuracy', 'Precision', 'TPR', 'FPR', 'F1-Score'])
ax6.table(cellText=df4.values, colLabels=df4.columns)
figure3.tight_layout()

pyplot.show()

# save data in csv file
figure.savefig("./bin_conf_matrix.png")
figure1.savefig("./multiple_class_conf_matrix.png")
figure2.savefig("./stats_of_multiple_class.png")
figure3.savefig("./stat_of_binary_class.png")
df1.to_csv("./stat_by_class1.csv", sep=';')
df2.to_csv("./stat_by_class2.csv", sep=';')
df3.to_csv("./stat_class1.csv", sep=';')
df4.to_csv("./stat_class2.csv", sep=';')


# ///////////////////////// unfortunately does not work
"""def get_all_roc_coordinates(y_proba):
    tpr_list = [0]
    fpr_list = [0]
    n = len(y_proba)
    stat = get_stat_by_class(get_conf_matrix(y_proba))
    for i in range(n):
        tpr = stat[i, 8]
        fpr =stat[i, 9]
        tpr_list.append(tpr)
        fpr_list.append(fpr)
    return tpr_list, fpr_list


def plot_roc_curve(tpr, fpr, scatter=True):
    pyplot.figure(figsize=(5, 5))
    if scatter:
        sb.scatterplot(x=fpr, y=tpr)
    sb.lineplot(x=fpr, y=tpr)
    sb.lineplot(x=[0, 1], y=[0, 1], color='green')
    pyplot.xlim(-0.05, 1.05)
    pyplot.ylim(-0.05, 1.05)
    pyplot.xlabel("False Positive Rate")
    pyplot.ylabel("True Positive Rate")


def plot_sklearn_roc_curve(y_real, y_pred):
    fpr, tpr, _ = roc_curve(y_real, y_pred)
    roc_display = RocCurveDisplay(fpr=fpr, tpr=tpr).plot()
    roc_display.figure_.set_size_inches(5, 5)
    pyplot.plot([0, 1], [0, 1], color='g')


def get_auc_roc_plots(model, prediction):
    pyplot.figure(figsize=(12, 8))
    bins = [i / 20 for i in range(20)] + [1]
    classes = model.classes_
    roc_auc_ovr = {}
    for i in range(len(classes)):
        # Gets the class
        c = classes[i]

        # Prepares an auxiliar dataframe to help with the plots
        df_aux = test_labels.copy()
        df_aux['class'] = [1 if y == c else 0 for y in prediction]
        df_aux['prob'] = prediction[:i]
        df_aux = df_aux.reset_index(drop=True)

        # Plots the probability distribution for the class and the rest
        ax = pyplot.subplot(2, 3, i + 1)
        sb.histplot(x="prob", data=df_aux, hue='class', color='b', ax=ax, bins=bins)
        ax.set_title(c)
        ax.legend([f"Class: {c}", "Rest"])
        ax.set_xlabel(f"P(x = {c})")

        # Calculates the ROC Coordinates and plots the ROC Curves
        ax_bottom = pyplot.subplot(2, 3, i + 4)
        tpr, fpr = get_all_roc_coordinates(df_aux['class'], df_aux['prob'])
        plot_roc_curve(tpr, fpr, scatter=False, ax=ax_bottom)
        ax_bottom.set_title("ROC Curve OvR")

        # Calculates the ROC AUC OvR
        roc_auc_ovr[c] = roc_auc_score(df_aux['class'], df_aux['prob'])
    pyplot.tight_layout()
    
    get_auc_roc_plots(model, predictions)
    """
